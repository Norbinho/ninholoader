@echo off
setlocal enabledelayedexpansion

:: 1. Setup Paths
set "BASE_DIR=%~dp0"
set "TOOL_PATH=%BASE_DIR%System tools"
set "FFMPEG_BIN=%TOOL_PATH%\ffmpeg\bin"
set "PATH=%TOOL_PATH%;%FFMPEG_BIN%;%PATH%"

:: Ensure we are in the correct folder
pushd "%BASE_DIR%"

set "status_msg="

:start
cls
color 0b

:: 2. Display Status Message
if not "!status_msg!"=="" (
    echo.
    echo  ===================================================
    echo  STATUS: !status_msg!
    echo  ===================================================
    set "status_msg="
)

:: 3. ASCII Art Header (Correctly Escaped)
echo.
echo  ###################################################
echo  #                                                 #
echo  #    __     _________     ____  _     ____        #
echo  #    \ \   / /__   __^|   ^|  _ \^| ^|   ^|  _ \       #
echo  #     \ \_/ /   ^| ^|______^| ^| ^| ^| ^|   ^| ^|_) ^|      #
echo  #      \   /    ^| ^|______^| ^|_^| ^| ^|___^|  __/       #
echo  #       ^|_^|     ^|_^|      ^|____/^|_____^|_^|          #
echo  #                                                 #
echo  #                by ninhoka                       #
echo  ###################################################
echo.

:: 4. Get Link
set "url="
set /p "url=> Enter Video Link: "
if "!url!"=="" goto start

:: 5. Parse and Show Title
echo.
echo  Fetching information...
set "vtitle="
for /f "delims=" %%i in ('^""!TOOL_PATH!\yt-dlp.exe" --get-title --quiet "!url!"^"') do (
    set "vtitle=%%i"
)

if "!vtitle!"=="" set "vtitle=Unknown Video"

echo.
echo  Title: !vtitle!
echo  -------------------------------------------

:: 6. Select Format
echo  Choose a preset or type a custom format code:
echo  [1] Best Video (MP4/MKV)
echo  [2] Best Audio (MP3)
echo.
set "choice="
set /p "choice=> Selection: "

if "!choice!"=="1" (
    set "dl_args=-f "bestvideo+bestaudio/best""
) else if "!choice!"=="2" (
    set "dl_args=-f "bestaudio" --extract-audio --audio-format mp3"
) else (
    set "dl_args=-f !choice!"
)

:: 7. Execution (Capturing log for duplicate check)
echo.
echo  Downloading...
:: We redirect the output to a temp file so we can read if it was skipped
"!TOOL_PATH!\yt-dlp.exe" %dl_args% ^
 --ffmpeg-location "!FFMPEG_BIN!" ^
 --no-mtime ^
 -o "%%USERPROFILE%%\Downloads\%%(title)s.%%(ext)s" "!url!" > "%temp%\ninho_log.txt" 2>&1

:: Show the log on screen so the user sees progress
type "%temp%\ninho_log.txt"

:: 8. Completion Check
if %errorlevel% equ 0 (
    :: Check the log file for the "already been downloaded" string
    findstr /i "already" "%temp%\ninho_log.txt" >nul
    if !errorlevel! equ 0 (
        set "status_msg=FILE ALREADY DOWNLOADED. SKIPPING."
    ) else (
        set "status_msg=DOWNLOAD COMPLETED: !vtitle!"
    )
    del "%temp%\ninho_log.txt"
    goto start
) else (
    echo.
    echo  [!] Download encountered an error. 
    del "%temp%\ninho_log.txt" 2>nul
    pause
    goto start
)