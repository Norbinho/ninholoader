@echo off
setlocal enabledelayedexpansion

:: --- CONFIGURATION ---
set "BASE_DIR=%~dp0"
set "TOOL_PATH=%BASE_DIR%System tools"
set "FFMPEG_DIR=%TOOL_PATH%\ffmpeg"
set "YTDLP_URL=https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe"
:: This URL points to the latest gyan.dev auto-build for ffmpeg
set "FFMPEG_URL=https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip"

cls
color 0e
echo ===================================================
echo           NINHOLOADER - SETUP ^& UPDATER
echo ===================================================
echo.

:: 1. Create Folders
if not exist "%TOOL_PATH%" mkdir "%TOOL_PATH%"
if not exist "%FFMPEG_DIR%" mkdir "%FFMPEG_DIR%"

:: 2. Download yt-dlp.exe
echo [1/3] Downloading latest yt-dlp.exe...
powershell -Command "Invoke-WebRequest -Uri '%YTDLP_URL%' -OutFile '%TOOL_PATH%\yt-dlp.exe'"
if %errorlevel% neq 0 (echo Error downloading yt-dlp! & pause & exit)

:: 3. Download FFmpeg Zip
echo [2/3] Downloading FFmpeg essentials...
powershell -Command "Invoke-WebRequest -Uri '%FFMPEG_URL%' -OutFile '%TOOL_PATH%\ffmpeg.zip'"
if %errorlevel% neq 0 (echo Error downloading FFmpeg! & pause & exit)

:: 4. Extract FFmpeg
echo [3/3] Extracting FFmpeg...
:: Create a temp folder for extraction
if exist "%TOOL_PATH%\temp_ext" rd /s /q "%TOOL_PATH%\temp_ext"
mkdir "%TOOL_PATH%\temp_ext"

tar -xf "%TOOL_PATH%\ffmpeg.zip" -C "%TOOL_PATH%\temp_ext"

:: Move contents from the versioned folder inside the zip to \ffmpeg\bin
echo Cleaning up folders...
for /d %%i in ("%TOOL_PATH%\temp_ext\*") do (
    xcopy "%%i\bin\*" "%FFMPEG_DIR%\bin\" /E /I /Y >nul
)

:: 5. Cleanup
rd /s /q "%TOOL_PATH%\temp_ext"
del "%TOOL_PATH%\ffmpeg.zip"

echo.
echo ===================================================
echo        SETUP COMPLETE! YOU ARE READY TO GO.
echo ===================================================
echo.
pause